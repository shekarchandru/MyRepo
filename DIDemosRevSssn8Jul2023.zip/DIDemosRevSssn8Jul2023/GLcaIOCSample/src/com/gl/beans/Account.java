package com.gl.beans;

public interface Account {

	public void calculateInterest();
}
