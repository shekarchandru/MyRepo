package com.gl.beans;

public class FDAccount implements Account{

	public void calculateInterest() {
		// TODO Auto-generated method stub
		System.out.println("Interest Calculated For FD ACCOUNT");
	}

}
