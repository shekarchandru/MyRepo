package com.gl.beans;

public class SBAccount implements Account{

	public void calculateInterest() {
		// TODO Auto-generated method stub
		System.out.println("Interest Calculated For SB ACCOUNT");
	}

}
