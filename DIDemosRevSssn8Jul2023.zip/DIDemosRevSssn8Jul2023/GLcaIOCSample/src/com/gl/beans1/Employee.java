package com.gl.beans1;

public class Employee {

	String empId;
	String empName;
	String empPhone;
	int empSalary;
	Address empAddress;
	
	public Employee() {
		super();
	}/**/

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpPhone() {
		return empPhone;
	}

	public void setEmpPhone(String empPhone) {
		this.empPhone = empPhone;
	}

	public int getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}

	public Address getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(Address empAddress) {
		this.empAddress = empAddress;
	}

	public void displayEmployeeDetails()
	{
		System.out.println("Employee Details are..");
		System.out.println("Employee Id is "+empId);
		System.out.println("Employee Name is "+empName);
		System.out.println("Employee Phone is "+empPhone);
		System.out.println("Employee Salary is "+empSalary);
		System.out.println("Address is "+empAddress);
	}
	
	
	

}
