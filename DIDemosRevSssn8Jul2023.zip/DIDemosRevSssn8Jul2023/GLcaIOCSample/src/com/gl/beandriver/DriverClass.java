package com.gl.beandriver;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.gl.beans.FDAccount;
import com.gl.beans.RDAccount;
import com.gl.beans.SBAccount;

public class DriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		SBAccount sbAccount = context.getBean("sbact", SBAccount.class);
		sbAccount.calculateInterest();
		
		FDAccount fdAccount = context.getBean("fdact", FDAccount.class);
		fdAccount.calculateInterest();
		
		RDAccount rdAccount = context.getBean("rdact", RDAccount.class);
		rdAccount.calculateInterest();
	
		
		
	}

}
