package com.gl.beandriver;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.gl.beans1.Employee;

public class EmpDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext1.xml");
		
		Employee emp1 = context.getBean("emp1", Employee.class);
		emp1.displayEmployeeDetails();

	}

}
