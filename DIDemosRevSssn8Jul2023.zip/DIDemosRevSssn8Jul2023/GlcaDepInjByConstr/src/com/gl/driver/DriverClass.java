package com.gl.driver;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.gl.beans.Student;

public class DriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		Student student1 = ctx.getBean("stud1", Student.class);
		student1.displayStudentDetails();
	}

}
