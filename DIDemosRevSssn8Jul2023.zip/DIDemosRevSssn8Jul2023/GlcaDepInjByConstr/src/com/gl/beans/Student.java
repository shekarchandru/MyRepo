package com.gl.beans;

public class Student {
	
		String studId;
		String studName;
		String studAddress;
		SubjectScores scores;
		
		public Student() {
			super();
		}

		public Student(String studId, String studName, String studAddress, SubjectScores scores) {
			super();
			this.studId = studId;
			this.studName = studName;
			this.studAddress = studAddress;
			this.scores = scores;
		}
		
		public void displayStudentDetails()
		{
			System.out.println("The Student Details ");
			System.out.println("Student Id "+studId);
			System.out.println("Student Name "+studName);
			System.out.println("Student Address "+studAddress);
			System.out.println("Scores "+scores);
		}
		
		

}
