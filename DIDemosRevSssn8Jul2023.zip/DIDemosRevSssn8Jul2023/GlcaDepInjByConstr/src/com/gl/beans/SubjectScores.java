package com.gl.beans;

public class SubjectScores {
	
	int subj1Score;
	int subj2Score;
	int subj3Score;
	int subj4Score;
	double average;
	
	public SubjectScores() {
		super();
	}

	public SubjectScores(int subj1Score, int subj2Score, int subj3Score, int subj4Score) {
		super();
		this.subj1Score = subj1Score;
		this.subj2Score = subj2Score;
		this.subj3Score = subj3Score;
		this.subj4Score = subj4Score;
		average = (subj1Score + subj2Score + subj3Score + subj4Score)/4;
	}

	@Override
	public String toString() {
		return "SubjectScores [subj1Score=" + subj1Score + ", subj2Score=" + subj2Score + ", subj3Score=" + subj3Score
				+ ", subj4Score=" + subj4Score + ", average=" + average + "]";
	}
	
	

}
