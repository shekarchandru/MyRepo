package com.gl.beans;

import org.springframework.stereotype.Component;

@Component
public class TrainerAdvice implements ExpertAdvice {

	@Override
	public void giveAdvice() {
		// TODO Auto-generated method stub
		System.out.println("Practice everyday on the Nets..");
	}

}
