package com.gl.beans;

import org.springframework.stereotype.Component;

@Component
public class CricketCoach implements SportsCoach {

	@Override
	public void scheduleTraining() {
		// TODO Auto-generated method stub
		System.out.println("Scheduling Training For Cricket ....");
	}

}
