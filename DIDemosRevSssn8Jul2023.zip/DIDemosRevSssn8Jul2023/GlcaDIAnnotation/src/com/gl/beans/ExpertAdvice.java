package com.gl.beans;

public interface ExpertAdvice {

	public void giveAdvice();
}
