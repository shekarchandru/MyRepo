package com.gl.beans;

import org.springframework.stereotype.Component;

@Component
public class PhysioAdvice implements ExpertAdvice{

	@Override
	public void giveAdvice() {
		// TODO Auto-generated method stub
		System.out.println("Do Warm up every day before training");
	}

}
