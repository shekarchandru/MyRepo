package com.gl.beans;

import org.springframework.stereotype.Component;

@Component
public class FootBallCoach implements SportsCoach{

	ExpertAdvice expertAdvice;
	
	public FootBallCoach(ExpertAdvice expertAdvice)
	{
		this.expertAdvice = expertAdvice;
	}
	
	@Override
	public void scheduleTraining() {
		// TODO Auto-generated method stub
		System.out.println("Training Scheduled for FootBall Training");
	}
	
	public void giveFootBallCoachAdvice()
	{
		expertAdvice.giveAdvice();
	}

}
