package com.gl.beans;

public interface SportsCoach {

	public void scheduleTraining();
}
