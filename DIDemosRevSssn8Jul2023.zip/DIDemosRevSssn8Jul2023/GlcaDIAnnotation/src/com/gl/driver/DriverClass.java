package com.gl.driver;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.gl.beans.CricketCoach;
import com.gl.beans.FootBallCoach;
import com.gl.config.SpringConfig;

public class DriverClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(SpringConfig.class);

		CricketCoach cCoach = ctx.getBean("cricketCoach", CricketCoach.class);
		cCoach.scheduleTraining();
		System.out.println("-----------------");
		FootBallCoach fCoach = ctx.getBean("footBallCoach", FootBallCoach.class);
		fCoach.scheduleTraining();
		fCoach.giveFootBallCoachAdvice();
	}

}
