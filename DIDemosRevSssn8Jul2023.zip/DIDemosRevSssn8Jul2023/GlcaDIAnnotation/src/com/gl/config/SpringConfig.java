package com.gl.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.gl.beans.CricketCoach;
import com.gl.beans.ExpertAdvice;
import com.gl.beans.FootBallCoach;
import com.gl.beans.TrainerAdvice;

@Configuration
@ComponentScan("com.gl.beans")
public class SpringConfig {
	
	
	@Bean
	public CricketCoach cricketCoach()
	{
		return new CricketCoach();
	}
	
	@Bean ExpertAdvice trainerAdvice()
	{
		return new TrainerAdvice();
	}
	
	@Bean ExpertAdvice PhysioAdvice()
	{
		return new com.gl.beans.PhysioAdvice();
	}
	
	@Bean FootBallCoach footBallCoach()
	{
		return new FootBallCoach(trainerAdvice());
	}

}
