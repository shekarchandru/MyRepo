package com.gl.security.studentmgmt.security;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MyUserDetailsTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
