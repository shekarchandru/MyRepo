package com.greatlearning.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.greatlearning.pojo.Employee;



@Controller
@RequestMapping("/employee")
public class EmployeeController {
	
	/*@RequestMapping("/registrationFrom")
	public String showRegistrationFrom(Model theModel) {
		
		Employee employee1 = new Employee();
		theModel.addAttribute("employee", employee1);
		return "employeeform";
	}*/
	@RequestMapping("/registrationform")
	public String showRegistrationForm(Model model)
	{
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "employeeform";
	}
	@RequestMapping("/processFrom")
	public String showRegistrationFrom(Model model,@ModelAttribute Employee employee) {
		
		
		model.addAttribute("employee", employee);
		return "processform";
	}
}
