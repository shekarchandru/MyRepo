package com.gl.mvcapp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gl.mvcapp.model.Student;
import com.gl.mvcapp.service.StudentService;

@Controller
@RequestMapping("/greet")
public class MyController {
	
	@Autowired
	StudentService studentSvc;
	
	@RequestMapping("/hello")
	public String sayHello(Model model)
	{
			String greetings = "Welcome to Spring MVC again";
			model.addAttribute("greeting", greetings);
			return "welcome";
	}
	
	@RequestMapping("/students")
	public String getStudents(Model model)
	{
		List <Student> students = studentSvc.getStudents();
		model.addAttribute("students", students);
		
		return "students-list";
	}
	

}
