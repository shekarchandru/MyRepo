package com.gl.mvcapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.mvcapp.dao.StudentDao;
import com.gl.mvcapp.model.Student;

@Service
public class StudentService {
	
	@Autowired
	StudentDao studentDao;
	public List <Student> getStudents()
	{
		return studentDao.getStudentsDao();
	}

}
