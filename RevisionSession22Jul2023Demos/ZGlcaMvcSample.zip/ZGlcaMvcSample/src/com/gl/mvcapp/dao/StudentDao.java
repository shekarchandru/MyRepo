package com.gl.mvcapp.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.gl.mvcapp.model.Student;

@Repository
public class StudentDao {
	
	List <Student> students;
	
	public StudentDao()
	{
		students = new ArrayList<Student>();
		
	}
	
	public List <Student> getStudentsDao()
	{
		students.add(new Student("S001","Harsha"));
		students.add(new Student("S002","Kiran"));
		students.add(new Student("S003","Mahesh"));
		return students;
	}

}
