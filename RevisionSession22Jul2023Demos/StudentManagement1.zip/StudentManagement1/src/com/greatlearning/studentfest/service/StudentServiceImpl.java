package com.greatlearning.studentfest.service;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.greatlearning.studentfest.entity.Student;



@Repository
public class StudentServiceImpl implements StudentService {

	private SessionFactory sessionfactory;
	private Session session;

	@Autowired
	public StudentServiceImpl(SessionFactory sessionfactory) {
		super();
		this.sessionfactory = sessionfactory;
		try {
			session = sessionfactory.getCurrentSession();
		} catch (HibernateException e) {
			session = sessionfactory.openSession();

		}
	}

	
	@Override
	@Transactional
	public List<Student> findAll() {

		// TODO Auto-generated method stub

		Transaction transaction = session.beginTransaction();
		List<Student> students = session.createQuery("from Student").list();
		transaction.commit();

		return students;
	}

	@Override
	@Transactional
	public void save(Student theStudent) {
		// TODO Auto-generated method stub
		Transaction transaction = session.beginTransaction();
		session.saveOrUpdate(theStudent);
		transaction.commit();

	}

	@Override
	@Transactional
	public void deleteById(int theId) {
		// TODO Auto-generated method stub
		Transaction transaction = session.beginTransaction();
		Student student = session.get(Student.class, theId);
		session.delete(student);
		transaction.commit();

	}

	@Override
	@Transactional
	public Student findById(int theId) {
		// TODO Auto-generated method stub
		Transaction transaction = session.beginTransaction();
		Student student = session.get(Student.class, theId);
		//session.get(Student.class, session);
		transaction.commit();
		return student;
	}

}
