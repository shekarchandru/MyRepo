package com.gl.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.gl.jdbc.connection.MyConnection;
import com.gl.jdbc.model.Employee;

public class EmployeeDao {
	
	Connection conn;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet rs;
	ArrayList <Employee> employees;
	MyConnection mycon;
	
	public EmployeeDao()
	{
		mycon = new MyConnection();
		employees = new ArrayList();
	}
	
	public ArrayList <Employee> getAllEmployees()
	{
		conn = mycon.getMyConnection();
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select * from Employee");
			while(rs.next())
			{
				Employee employee = new Employee();
				String empId = rs.getString(1);
				employee.setEmployeeId(empId);
				
				employee.setEmployeeName(rs.getString(2));
				employee.setEmployeeAddress(rs.getString(3));
				employee.setEmployeePhone(rs.getString(4));
				employee.setEmployeeSalary(rs.getInt(5));
				employee.setIncomeTax(rs.getFloat(6));
				
				employees.add(employee);
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return employees;
	}
	
	public Employee getEmployeeById(String empId)
	{
		conn = mycon.getMyConnection();
		Employee employee = new Employee();
		// select * from Employee where employeeId = ?
		String  query = "select * from Employee where employeeId = ?";
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, empId);
			rs = pstmt.executeQuery();
			rs.next();
			employee.setEmployeeId(rs.getString(1));
			employee.setEmployeeName(rs.getString(2));
			employee.setEmployeeAddress(rs.getString(3));
			employee.setEmployeePhone(rs.getString(4));
			employee.setEmployeeSalary(rs.getInt(5));
			employee.setIncomeTax(rs.getFloat(6));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employee;
		
	}
	public boolean insertEmployee(Employee employee)
	{
		conn = mycon.getMyConnection();
		boolean flag = false;
		// insert into Employee values(?,?,?,?,?,?);
		String iquery="insert into Employee values(?,?,?,?,?,?)";
		try {
			pstmt = conn.prepareStatement(iquery);
			pstmt.setString(1, employee.getEmployeeId());
			pstmt.setString(2, employee.getEmployeeName());
			pstmt.setString(3, employee.getEmployeeAddress());
			pstmt.setString(4, employee.getEmployeePhone());
			pstmt.setInt(5, employee.getEmployeeSalary());
			pstmt.setFloat(6, employee.getIncomeTax());
			pstmt.execute();
			flag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
		
	}
	public boolean updateEmployee(Employee employee)
	{
		conn = mycon.getMyConnection();
		boolean flag = false;
		String queryU = "update Employee set employeeAddress = ? where employeeId = ?";
		try {
			pstmt = conn.prepareStatement(queryU);
			pstmt.setString(1, employee.getEmployeeAddress());
			pstmt.setString(2, employee.getEmployeeId());
			pstmt.execute();
			flag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	public boolean deleteEmployeeById(String empIdDel)
	{
		conn = mycon.getMyConnection();
		boolean flagDel = false;
		String queryDel = "delete from Employee where employeeId = ?";
		try {
			pstmt = conn.prepareStatement(queryDel);
			pstmt.setString(1, empIdDel);
		int x=pstmt.executeUpdate();
		if( x >= 1)
		{
			System.out.println("x is "+x);
			flagDel = true;
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flagDel;
	}
	

}
