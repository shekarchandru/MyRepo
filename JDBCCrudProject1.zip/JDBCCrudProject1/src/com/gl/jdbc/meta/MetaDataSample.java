package com.gl.jdbc.meta;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import com.gl.jdbc.connection.MyConnection;

public class MetaDataSample {

	Connection con;
	MyConnection mycon = new MyConnection();
	public void getDatabaseMetaData()
	{
		con = mycon.getMyConnection();
		try {
			DatabaseMetaData dbmd = con.getMetaData();
			System.out.println(" Database Major Version :"+dbmd.getDatabaseMajorVersion());
			System.out.println("Database Minor Version :"+dbmd.getDatabaseMinorVersion());
			System.out.println("Database Product Name "+dbmd.getDatabaseProductName());
			System.out.println("ProductVersion "+dbmd.getDatabaseProductVersion());
			System.out.println("Driver Name "+dbmd.getDriverName());
			System.out.println("DRiver Version Major "+dbmd.getDriverMajorVersion());
			System.out.println("Driver Version Minor "+dbmd.getDriverMinorVersion());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void getResultSetMetaData()
	{
		con = mycon.getMyConnection();
		String query = "select * from Employee";
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			System.out.println("Column Count "+rsmd.getColumnCount());
			System.out.println("Column 1 "+rsmd.getColumnName(1));
			System.out.println("Column 2 "+rsmd.getColumnName(2));
			System.out.println("Column 5 "+rsmd.getColumnName(5));
			System.out.println("Column 5 type "+rsmd.getColumnType(5));
			System.out.println("Column 5 DB type"+rsmd.getColumnTypeName(5));
			System.out.println("Table Name "+rsmd.getTableName(1));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MetaDataSample mds = new MetaDataSample();
		System.out.println("--------------DatabaseMetaData---------------");
		mds.getDatabaseMetaData();
		System.out.println("-----------ResultSetMetaData-----------");
		mds.getResultSetMetaData();
	

	}

}
