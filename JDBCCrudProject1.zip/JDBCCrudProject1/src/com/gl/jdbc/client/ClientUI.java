package com.gl.jdbc.client;

public class ClientUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDBManager empManager = new EmployeeDBManager();
		empManager.showMenu();

	}

}
